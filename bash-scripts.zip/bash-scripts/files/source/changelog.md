## 11.2.3
### Added
- Splines
- Two cows in a window
### Removed
- Aliens
- Nessie